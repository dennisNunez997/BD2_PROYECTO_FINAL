﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Difuntos.Models;

namespace Difuntos.Controllers
{
    public class encabezado_formularioController : Controller
    {
        private Difuntos_FormularioEntities db = new Difuntos_FormularioEntities();

        // GET: encabezado_formulario
        public ActionResult Index()
        {
            var encabezado_formulario = db.encabezado_formulario.Include(e => e.provincia);
            return View(encabezado_formulario.ToList());
        }

        // GET: encabezado_formulario/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            encabezado_formulario encabezado_formulario = db.encabezado_formulario.Find(id);
            if (encabezado_formulario == null)
            {
                return HttpNotFound();
            }
            return View(encabezado_formulario);
        }

        // GET: encabezado_formulario/Create
        public ActionResult Create()
        {
            ViewBag.pk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia");
            return View();
        }

        // POST: encabezado_formulario/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id_encabezado,oficina_registro,oficinaNum,pk_provincia,fecha_inscripcion,usoInec_fecha_critica,acta_inscripcion")] encabezado_formulario encabezado_formulario)
        {
            if (ModelState.IsValid)
            {
                db.encabezado_formulario.Add(encabezado_formulario);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.pk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia", encabezado_formulario.pk_provincia);
            return View(encabezado_formulario);
        }

        // GET: encabezado_formulario/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            encabezado_formulario encabezado_formulario = db.encabezado_formulario.Find(id);
            if (encabezado_formulario == null)
            {
                return HttpNotFound();
            }
            ViewBag.pk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia", encabezado_formulario.pk_provincia);
            return View(encabezado_formulario);
        }

        // POST: encabezado_formulario/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_encabezado,oficina_registro,oficinaNum,pk_provincia,fecha_inscripcion,usoInec_fecha_critica,acta_inscripcion")] encabezado_formulario encabezado_formulario)
        {
            if (ModelState.IsValid)
            {
                db.Entry(encabezado_formulario).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.pk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia", encabezado_formulario.pk_provincia);
            return View(encabezado_formulario);
        }

        // GET: encabezado_formulario/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            encabezado_formulario encabezado_formulario = db.encabezado_formulario.Find(id);
            if (encabezado_formulario == null)
            {
                return HttpNotFound();
            }
            return View(encabezado_formulario);
        }

        // POST: encabezado_formulario/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            encabezado_formulario encabezado_formulario = db.encabezado_formulario.Find(id);
            db.encabezado_formulario.Remove(encabezado_formulario);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
