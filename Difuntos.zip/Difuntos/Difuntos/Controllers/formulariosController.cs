﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Difuntos.Models;

namespace Difuntos.Controllers
{
    public class formulariosController : Controller
    {
        private Difuntos_FormularioEntities db = new Difuntos_FormularioEntities();

        // GET: formularios
        public ActionResult Index()
        {
            var formulario = db.formulario.Include(f => f.certificado_por).Include(f => f.encabezado_formulario).Include(f => f.EstadoCivil).Include(f => f.etnia).Include(f => f.lugar_donde_ocurrio_hecho).Include(f => f.necropsia).Include(f => f.provincia).Include(f => f.funcionario).Include(f => f.Nivel_instruccion).Include(f => f.lugar_fallecimiento).Include(f => f.mortalidad_materna).Include(f => f.relacion_parentesco).Include(f => f.muerte_accidental_violenta);
            return View(formulario.ToList());
        }

        // GET: formularios/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            formulario formulario = db.formulario.Find(id);
            if (formulario == null)
            {
                return HttpNotFound();
            }
            return View(formulario);
        }

        // GET: formularios/Create
        public ActionResult Create()
        {
            ViewBag.id_certificado_fk = new SelectList(db.certificado_por, "id_certificado", "certificado_por1");
            ViewBag.id_encabezado_fk = new SelectList(db.encabezado_formulario, "id_encabezado", "oficina_registro");
            ViewBag.pk_Estado_Civil_id = new SelectList(db.EstadoCivil, "Estado_Civil_ID", "Estado_Fallecido");
            ViewBag.id_etnia_pk = new SelectList(db.etnia, "id_etnia", "etnia1");
            ViewBag.fk_lugar_hecho = new SelectList(db.lugar_donde_ocurrio_hecho, "id_lugar_hecho", "lugar_hecho");
            ViewBag.fk_necropsia = new SelectList(db.necropsia, "id_necropsia", "necropsia1");
            ViewBag.fk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia");
            ViewBag.id_funcionario_fk = new SelectList(db.funcionario, "id_funcionario", "nombre_funcionario");
            ViewBag.instruccion_nivel_pk = new SelectList(db.Nivel_instruccion, "nivel_instruccion_id", "instruccion_nivel");
            ViewBag.lugar_fallecimiento_pk = new SelectList(db.lugar_fallecimiento, "lugar_fallecimiento_id", "lugar_fallecimiento1");
            ViewBag.mortalidad_materna_fk = new SelectList(db.mortalidad_materna, "mortalidad_materna_id", "mortalidad_materna1");
            ViewBag.relacion_con_fallecido_fk = new SelectList(db.relacion_parentesco, "id_relacion_con_fallecido", "relacion_parentesco1");
            ViewBag.tipo_muerte_fk = new SelectList(db.muerte_accidental_violenta, "tipo_muerte_id", "tipo_muerte");
            return View();
        }

        // POST: formularios/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id_encabezado_fk,id_funcionario_fk,id_formulario,nombre_fallecido,nacionalidad_fallecido,pais_fallecido,cedula_difunto,sexo_difunto,fecha_nacimiento_difunto,fecha_fallecimiento_difunto,edad_horas_difunto,edad_dias_difunto,edad_meses_difuntos,años_cumplidos_difunto,nom_provincia_difunto,canton_difunto,parroquia_difunto,localidad_difunto,direccion_difunto,DPA_INEC,localidad_inec,pk_Estado_Civil_id,sabia_leer_difunto,instruccion_nivel_pk,id_etnia_pk,lugar_fallecimiento_pk,nombre_lugar_fallecimiento,fk_provincia,uso_inec_codigo,localidad_donde_fallecio,direccion_donde_fallecio,telefono_lugar_fallecido,DPA_fallecimiento_INEC,localidad_fallecimiento_INEC,causa1_fallecimiento,causas_antecedentes_fallecimiento1,causas_antecedentes_fallecimiento2,causas_antecedentes_fallecimiento3,estados_patologicos,tiempo_causa1,tiempo_causa_antecedente1,tiempo_causa_antecedente2,tiempo_causa_antecedente3,tiempo_estado_patologico,codigoCIE_1,codigoCIE_2,codigoCIE_3,codigoCIE_4,codigoCIE_5,uso_inec_tiempo,mortalidad_materna_fk,tipo_muerte_fk,fk_lugar_hecho,descripcion_muerte,fk_necropsia,causa_probable_muerte,sintoma,testigo1,direccion_testigo1,telefono_testigo1,testigo2,direccion_testigo2,telefono_testigo2,id_certificado_fk,nombre_apellido_certifica,cedula_certifica,direccion_certifica,telefono_certifica,nombre_quien_solicita_inscripcion,edad_quien_solicita_inscripcion,relacion_con_fallecido_fk,observaciones")] formulario formulario)
        {
            if (ModelState.IsValid)
            {
                db.formulario.Add(formulario);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.id_certificado_fk = new SelectList(db.certificado_por, "id_certificado", "certificado_por1", formulario.id_certificado_fk);
            ViewBag.id_encabezado_fk = new SelectList(db.encabezado_formulario, "id_encabezado", "oficina_registro", formulario.id_encabezado_fk);
            ViewBag.pk_Estado_Civil_id = new SelectList(db.EstadoCivil, "Estado_Civil_ID", "Estado_Fallecido", formulario.pk_Estado_Civil_id);
            ViewBag.id_etnia_pk = new SelectList(db.etnia, "id_etnia", "etnia1", formulario.id_etnia_pk);
            ViewBag.fk_lugar_hecho = new SelectList(db.lugar_donde_ocurrio_hecho, "id_lugar_hecho", "lugar_hecho", formulario.fk_lugar_hecho);
            ViewBag.fk_necropsia = new SelectList(db.necropsia, "id_necropsia", "necropsia1", formulario.fk_necropsia);
            ViewBag.fk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia", formulario.fk_provincia);
            ViewBag.id_funcionario_fk = new SelectList(db.funcionario, "id_funcionario", "nombre_funcionario", formulario.id_funcionario_fk);
            ViewBag.instruccion_nivel_pk = new SelectList(db.Nivel_instruccion, "nivel_instruccion_id", "instruccion_nivel", formulario.instruccion_nivel_pk);
            ViewBag.lugar_fallecimiento_pk = new SelectList(db.lugar_fallecimiento, "lugar_fallecimiento_id", "lugar_fallecimiento1", formulario.lugar_fallecimiento_pk);
            ViewBag.mortalidad_materna_fk = new SelectList(db.mortalidad_materna, "mortalidad_materna_id", "mortalidad_materna1", formulario.mortalidad_materna_fk);
            ViewBag.relacion_con_fallecido_fk = new SelectList(db.relacion_parentesco, "id_relacion_con_fallecido", "relacion_parentesco1", formulario.relacion_con_fallecido_fk);
            ViewBag.tipo_muerte_fk = new SelectList(db.muerte_accidental_violenta, "tipo_muerte_id", "tipo_muerte", formulario.tipo_muerte_fk);
            return View(formulario);
        }

        // GET: formularios/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            formulario formulario = db.formulario.Find(id);
            if (formulario == null)
            {
                return HttpNotFound();
            }
            ViewBag.id_certificado_fk = new SelectList(db.certificado_por, "id_certificado", "certificado_por1", formulario.id_certificado_fk);
            ViewBag.id_encabezado_fk = new SelectList(db.encabezado_formulario, "id_encabezado", "oficina_registro", formulario.id_encabezado_fk);
            ViewBag.pk_Estado_Civil_id = new SelectList(db.EstadoCivil, "Estado_Civil_ID", "Estado_Fallecido", formulario.pk_Estado_Civil_id);
            ViewBag.id_etnia_pk = new SelectList(db.etnia, "id_etnia", "etnia1", formulario.id_etnia_pk);
            ViewBag.fk_lugar_hecho = new SelectList(db.lugar_donde_ocurrio_hecho, "id_lugar_hecho", "lugar_hecho", formulario.fk_lugar_hecho);
            ViewBag.fk_necropsia = new SelectList(db.necropsia, "id_necropsia", "necropsia1", formulario.fk_necropsia);
            ViewBag.fk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia", formulario.fk_provincia);
            ViewBag.id_funcionario_fk = new SelectList(db.funcionario, "id_funcionario", "nombre_funcionario", formulario.id_funcionario_fk);
            ViewBag.instruccion_nivel_pk = new SelectList(db.Nivel_instruccion, "nivel_instruccion_id", "instruccion_nivel", formulario.instruccion_nivel_pk);
            ViewBag.lugar_fallecimiento_pk = new SelectList(db.lugar_fallecimiento, "lugar_fallecimiento_id", "lugar_fallecimiento1", formulario.lugar_fallecimiento_pk);
            ViewBag.mortalidad_materna_fk = new SelectList(db.mortalidad_materna, "mortalidad_materna_id", "mortalidad_materna1", formulario.mortalidad_materna_fk);
            ViewBag.relacion_con_fallecido_fk = new SelectList(db.relacion_parentesco, "id_relacion_con_fallecido", "relacion_parentesco1", formulario.relacion_con_fallecido_fk);
            ViewBag.tipo_muerte_fk = new SelectList(db.muerte_accidental_violenta, "tipo_muerte_id", "tipo_muerte", formulario.tipo_muerte_fk);
            return View(formulario);
        }

        // POST: formularios/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_encabezado_fk,id_funcionario_fk,id_formulario,nombre_fallecido,nacionalidad_fallecido,pais_fallecido,cedula_difunto,sexo_difunto,fecha_nacimiento_difunto,fecha_fallecimiento_difunto,edad_horas_difunto,edad_dias_difunto,edad_meses_difuntos,años_cumplidos_difunto,nom_provincia_difunto,canton_difunto,parroquia_difunto,localidad_difunto,direccion_difunto,DPA_INEC,localidad_inec,pk_Estado_Civil_id,sabia_leer_difunto,instruccion_nivel_pk,id_etnia_pk,lugar_fallecimiento_pk,nombre_lugar_fallecimiento,fk_provincia,uso_inec_codigo,localidad_donde_fallecio,direccion_donde_fallecio,telefono_lugar_fallecido,DPA_fallecimiento_INEC,localidad_fallecimiento_INEC,causa1_fallecimiento,causas_antecedentes_fallecimiento1,causas_antecedentes_fallecimiento2,causas_antecedentes_fallecimiento3,estados_patologicos,tiempo_causa1,tiempo_causa_antecedente1,tiempo_causa_antecedente2,tiempo_causa_antecedente3,tiempo_estado_patologico,codigoCIE_1,codigoCIE_2,codigoCIE_3,codigoCIE_4,codigoCIE_5,uso_inec_tiempo,mortalidad_materna_fk,tipo_muerte_fk,fk_lugar_hecho,descripcion_muerte,fk_necropsia,causa_probable_muerte,sintoma,testigo1,direccion_testigo1,telefono_testigo1,testigo2,direccion_testigo2,telefono_testigo2,id_certificado_fk,nombre_apellido_certifica,cedula_certifica,direccion_certifica,telefono_certifica,nombre_quien_solicita_inscripcion,edad_quien_solicita_inscripcion,relacion_con_fallecido_fk,observaciones")] formulario formulario)
        {
            if (ModelState.IsValid)
            {
                db.Entry(formulario).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.id_certificado_fk = new SelectList(db.certificado_por, "id_certificado", "certificado_por1", formulario.id_certificado_fk);
            ViewBag.id_encabezado_fk = new SelectList(db.encabezado_formulario, "id_encabezado", "oficina_registro", formulario.id_encabezado_fk);
            ViewBag.pk_Estado_Civil_id = new SelectList(db.EstadoCivil, "Estado_Civil_ID", "Estado_Fallecido", formulario.pk_Estado_Civil_id);
            ViewBag.id_etnia_pk = new SelectList(db.etnia, "id_etnia", "etnia1", formulario.id_etnia_pk);
            ViewBag.fk_lugar_hecho = new SelectList(db.lugar_donde_ocurrio_hecho, "id_lugar_hecho", "lugar_hecho", formulario.fk_lugar_hecho);
            ViewBag.fk_necropsia = new SelectList(db.necropsia, "id_necropsia", "necropsia1", formulario.fk_necropsia);
            ViewBag.fk_provincia = new SelectList(db.provincia, "pk_provincia", "nombre_Provincia", formulario.fk_provincia);
            ViewBag.id_funcionario_fk = new SelectList(db.funcionario, "id_funcionario", "nombre_funcionario", formulario.id_funcionario_fk);
            ViewBag.instruccion_nivel_pk = new SelectList(db.Nivel_instruccion, "nivel_instruccion_id", "instruccion_nivel", formulario.instruccion_nivel_pk);
            ViewBag.lugar_fallecimiento_pk = new SelectList(db.lugar_fallecimiento, "lugar_fallecimiento_id", "lugar_fallecimiento1", formulario.lugar_fallecimiento_pk);
            ViewBag.mortalidad_materna_fk = new SelectList(db.mortalidad_materna, "mortalidad_materna_id", "mortalidad_materna1", formulario.mortalidad_materna_fk);
            ViewBag.relacion_con_fallecido_fk = new SelectList(db.relacion_parentesco, "id_relacion_con_fallecido", "relacion_parentesco1", formulario.relacion_con_fallecido_fk);
            ViewBag.tipo_muerte_fk = new SelectList(db.muerte_accidental_violenta, "tipo_muerte_id", "tipo_muerte", formulario.tipo_muerte_fk);
            return View(formulario);
        }

        // GET: formularios/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            formulario formulario = db.formulario.Find(id);
            if (formulario == null)
            {
                return HttpNotFound();
            }
            return View(formulario);
        }

        // POST: formularios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            formulario formulario = db.formulario.Find(id);
            db.formulario.Remove(formulario);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
