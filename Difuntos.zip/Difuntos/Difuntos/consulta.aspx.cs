﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace Difuntos
{
    public partial class consulta : System.Web.UI.Page
    {
        public SqlConnection cn = new SqlConnection("data source=LAPTOP-2R8CDKEI;initial catalog=Difuntos_Formulario;integrated security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter( "select * from dbo.encabezado_formulario", cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            this.GridView1.DataSource=dt;
            GridView1.DataBind();
        }

        void Consulta()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from dbo.encabezado_formulario where oficina_registro like '" + TextBox1.Text+"'", cn);
            DataTable dt = new DataTable();

            da.Fill(dt);

            this.GridView1.DataSource = dt;
            GridView1.DataBind();

        }


        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Consulta(); 
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            Consulta();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}